var port = chrome.runtime.connectNative("com.csg.dscreader");
if (!port) {
    alert("OPEN ERROR: " + JSON.stringify(chrome.runtime.lastError));
}

//Receive Message From Content 
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        console.log(sender.tab ?
            "from a content script:" + sender.tab.url :
            "From the extension");
        //alert("Extension Received :" +JSON.stringify(request));

        //Message to host   
        port.postMessage(request);
        return true;

    });

//Receive Message from Host
port.onMessage.addListener(function (msg) {
    //alert("Received from host" + JSON.stringify(msg));

    //Send msg to content script
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, msg, function (response) { });
    });

});

port.onDisconnect.addListener(function () {
    console.log("Disconnected");
});