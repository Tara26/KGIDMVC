console.log("content script loaded");


//Get Message from Page     
window.addEventListener("message", function (event) {
    // We only accept messages from ourselves
    if (event.source !== window)
        return;

    if (event.data.src && (event.data.src === "user_page.js")) {
        event.data["origin"] = location.origin;
        console.log("Content script received data from page : ");
        console.log(event.data);
        //Send Message to Extension
        chrome.runtime.sendMessage(event.data, function (resp) { });
    }
}, false);



//Get Message from Extension
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        //console.log(sender.tab ? "from a content script:" + sender.tab.url :"from the extension");
        console.log("Content script received from Extension : ");
        console.log(request);

        //sendResponse(request);	
        // post messages to page
        request['src'] = "content.js";
        window.postMessage(request, '*');
    }
);


/////// inject content of user_page.js to the DOM of page  ///////////////
var s = document.createElement('script');
s.type = 'text/javascript';
s.innerHTML = '// Promises \n\
var _tp_promises = {};\n\
//Get Message From content script \n\
window.addEventListener("message", function(event) { \n\
		if(event.source !== window) return;			 \n\
		if(event.data.src && (event.data.src === "content.js")) { \n\
			console.log("Page received: "); 						\n\
			console.log(event.data); 							\n\
			// Get the promise									\n\
			if(event.data.nonce) {								\n\
				 var p = _tp_promises[event.data.nonce]; 		\n\
				 // resolve										\n\
				 if(event.data.status_cd === 1){				\n\
					p.resolve(event.data.result);				\n\
				 }else{											\n\
				 // reject										\n\
					p.reject(new Error(event.data.result));		\n\
				 }												\n\
				 delete _tp_promises[event.data.nonce];			\n\
			}else {  											\n\
				console.log("No nonce in event msg");			\n\
			}													\n\
		}														\n\
	});															\n\
																\n\
    var DSCSignRegSignedExtension= new TpCrypto();								\n\
	function TpCrypto (){										\n\
																\n\
	function nonce() {											\n\
	  var val = ""; 										    \n\
	  var hex = "abcdefghijklmnopqrstuvwxyz0123456789";	         	\n\
	  for(var i = 0; i < 16; i++)							     	\n\
		val += hex.charAt(Math.floor(Math.random() * hex.length));	\n\
	  return val;											    	\n\
	}															\n\
																\n\
	function messagePromise(msg) { 								\n\
		return new Promise(function(resolve, reject) { 			\n\
			// amend with necessary metadata 					\n\
			msg["nonce"] = nonce(); 							\n\
			msg["src"] = "user_page.js"; 						\n\
			// send message 									\n\
			window.postMessage(msg, "*"); 						\n\
			// and store promise callbacks 						\n\
			_tp_promises[msg.nonce] = {							\n\
				resolve: resolve, 								\n\
				reject: reject 									\n\
			}; 													\n\
		}); 													\n\
	}															\n\
	this.signWord = function(hash){							\n\
		var msg= { action:"GSTReturnSign", hash:hash };			\n\
		return messagePromise(msg);								\n\
	}															\n\
	this.signGstHash = function(hash){							\n\
		var msg= { action:"GSTReturnSign", hash:hash };			\n\
		return messagePromise(msg);								\n\
	}															\n\
	this.signITHash = function(hash, PAN){							\n\
		var msg= { action:"ITReturnSign", hash:hash, PAN:PAN };			\n\
		return messagePromise(msg);								\n\
	}															\n\
	this.getSelectedCertificate = function(){					\n\
		var msg= { action:"GetSelCertFromToken" };				\n\
		return messagePromise(msg);								\n\
	}															\n\
	this.signPdfHash1 = function(RefNumber,RefTypeID,UnsignedFileWS,signedFileWS){					\n\
		var msg= { action:"PdfSignature",RefNumber:RefNumber,RefTypeID:RefTypeID,UnsignedFileWS:UnsignedFileWS,signedFileWS:signedFileWS};		\n\
		return messagePromise(msg);								\n\
	}															\n\
	this.signAuthToken = function(authtoken,certAlgorithm){					\n\
		var msg= { action:"SignAuthToken", authToken:authtoken, hashAlgorithm:certAlgorithm };		\n\
		return messagePromise(msg);								\n\
	}															\n\
}//End of TpCrypto class										\n\
';
(document.head || document.documentElement)
    .appendChild(s);